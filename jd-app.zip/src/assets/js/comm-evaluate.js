export default function drag (id) {
  //  代码内容
}
