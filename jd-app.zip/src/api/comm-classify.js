import req from '../fetch/index.js'

const config = {
  // portExport: {
  //   url: '/api/media/stimulate/exportExcel',
  //   method: 'post',
  //   fileConfig: {
  //     type: 'file',
  //     fileName: '销售激励报表'
  //   }
  // },
  // 一级分类查询
  queryOneClass: {
    url: '/app/customer/queryOneClass',
    method: 'post'
  },
  // 二级分类查询
  queryTwoClass: {
    url: '/app/customer/queryTwoClass',
    method: 'post'
  }
}

const request = function (funcName, requestParam) {
  return req(config[funcName].url, config[funcName].method, requestParam, {}, config[funcName].fileConfig)
}
export default request
